const themeButton = document.querySelector(".theme-toggle");
const menuButton = document.querySelector(".menu-toggle");
const nav = document.querySelector(".main-nav");

themeButton.addEventListener("click", () => {
  document.body.classList.toggle("dark");
  const darkOn = document.body.classList.contains("dark");
  themeButton.textContent = darkOn ? "☀" : "☾";
  themeButton.setAttribute("aria-label", darkOn ? "Switch to light mode" : "Switch to dark mode");
  try { localStorage.setItem("bhavani-theme", darkOn ? "dark" : "light"); } catch (_) {}
});

try {
  if (localStorage.getItem("bhavani-theme") === "dark") {
    document.body.classList.add("dark");
    themeButton.textContent = "☀";
    themeButton.setAttribute("aria-label", "Switch to light mode");
  }
} catch (_) {}

menuButton.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(isOpen));
  menuButton.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
  menuButton.textContent = isOpen ? "×" : "☰";
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuButton.setAttribute("aria-expanded", "false");
  menuButton.setAttribute("aria-label", "Open navigation");
  menuButton.textContent = "☰";
}));

document.querySelector("#contact-form").addEventListener("submit", event => {
  event.preventDefault();
  const name = document.querySelector("#contact-name").value.trim();
  const message = document.querySelector("#contact-message").value.trim();
  const subject = encodeURIComponent(`Portfolio contact from ${name}`);
  const body = encodeURIComponent(`Hello Bhavani,\n\n${message}\n\nFrom: ${name}`);
  document.querySelector(".form-status").textContent = "Opening your email app. If it doesn't open, email gowdabhavani869@gmail.com directly.";
  window.location.href = `mailto:gowdabhavani869@gmail.com?subject=${subject}&body=${body}`;
});
